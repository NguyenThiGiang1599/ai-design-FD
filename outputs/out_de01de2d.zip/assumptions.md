Assumptions auto-generated not available; please review.
