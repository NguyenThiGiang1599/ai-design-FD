# Backlog — Inbound (MVP)
- Core flows
- Task creation & confirmation
- Inventory updates & audit
