# UI Wireframes (low-fi, textual)

## Web (Clerk)
- List → Detail → Monitor dashboards

## Android Handheld (Operator)
- Login → Select Task → Scan → Confirm → Offline queue + retry sync
